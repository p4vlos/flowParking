//
//  ViewController.swift
//  FlowParking
//
//  Created by Pavlos Nicolaou on 20/01/2017.
//  Copyright © 2017 Pavlos Nicolaou. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var distanceLbl: UILabel!
    @IBOutlet weak var rawDistanceLbl: UILabel!
    @IBOutlet weak var accuracyLbl: UILabel!
    var locationManager: CLLocationManager!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.requestAlwaysAuthorization()
        
        view.backgroundColor = UIColor.gray
        print("did load")
        
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedAlways {
            print("status authorised")
            if CLLocationManager.isMonitoringAvailable(for: CLBeaconRegion.self) {
                print("is monitoring")
                if CLLocationManager.isRangingAvailable() {
                    print("scanning")
                    startScanning()
                }
            }
        }
    }

    func startScanning() {
        print("start Scanning")
        //let uuid = UUID(uuidString: "f7826da6-4fa2-4e98-8024-bc5b71e0893e")!
        //let beaconRegion = CLBeaconRegion(proximityUUID: uuid, major: 123, minor: 456, identifier: "MyBeacon")
        //locationManager.startMonitoring(for: beaconRegion)
        //locationManager.startRangingBeacons(in: beaconRegion)
        
        if let uuid = NSUUID(uuidString: "f7826da6-4fa2-4e98-8024-bc5b71e0893e") {
            let beaconRegion = CLBeaconRegion(proximityUUID: uuid as UUID, identifier: "MyBeacon")
            locationManager.startMonitoring(for: beaconRegion)
            locationManager.startRangingBeacons(in: beaconRegion)
        }
        else {
            NSLog("Invalid UUID format")
        }
        
        
        
    }
    
    func locationManager(_ manager: CLLocationManager, didRangeBeacons beacons: [CLBeacon], in region: CLBeaconRegion) {
        //printing all info for the beacon
        self.rawDistanceLbl.text = "\(beacons)"
        self.accuracyLbl.text = "\(manager.desiredAccuracy)"
        //print(manager.desiredAccuracy)
        //print(beacons)
        if beacons.count > 0 {
            updateDistance(beacons[0].proximity)
            print("found more than one beacon")
        } else {
            updateDistance(.unknown)
            print("found only one beacon")
        }
    }
    
    func updateDistance(_ distance: CLProximity) {
        UIView.animate(withDuration: 0.8) {
            switch distance {
            case .unknown:
                self.view.backgroundColor = UIColor.gray
                self.distanceLbl.text = "UNKNOWN"
                print("distance Unknown")
            case .far:
                self.view.backgroundColor = UIColor.blue
                self.distanceLbl.text = "FAR"
                print("distance Far")
            case .near:
                self.view.backgroundColor = UIColor.orange
                self.distanceLbl.text = "NEAR"
                print("distance Near")
            case .immediate:
                self.view.backgroundColor = UIColor.red
                self.distanceLbl.text = "You got it"
                print("distance Immediate")
            }
        }
    }
}

